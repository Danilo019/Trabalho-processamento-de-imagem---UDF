// Função para gerar e exibir o histograma
function gerarHistograma() {
    const canvasOriginal = document.getElementById('canvas-original');
    const contextOriginal = canvasOriginal.getContext('2d');
    const imageData = contextOriginal.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);
    const data = imageData.data;

    // Inicializa os contadores para cada componente de cor (R, G, B, escala de cinza)
    const histograma = {
        red: Array(256).fill(0),
        green: Array(256).fill(0),
        blue: Array(256).fill(0),
        grayscale: Array(256).fill(0)
    };

    // Percorre os dados da imagem e incrementa os contadores do histograma
    for (let i = 0; i < data.length; i += 4) {
        const red = data[i];
        const green = data[i + 1];
        const blue = data[i + 2];
        const grayscale = Math.round((red + green + blue) / 3); // Média dos valores de R, G, B

        histograma.red[red]++;
        histograma.green[green]++;
        histograma.blue[blue]++;
        histograma.grayscale[grayscale]++;
    }

    desenharHistograma(histograma); // Chama a função para desenhar o histograma
}

// Função para desenhar o histograma usando Chart.js
function desenharHistograma(histograma) {
    const canvasHistograma = document.getElementById('canvas-histograma-linhas').getContext('2d');
    const corSelecionada = document.getElementById('color-select').value;

    let data, borderColor;

    switch (corSelecionada) {
        case 'red':
            data = histograma.red;
            borderColor = 'rgba(255, 99, 132, 1)';
            break;
        case 'green':
            data = histograma.green;
            borderColor = 'rgba(75, 192, 192, 1)';
            break;
        case 'blue':
            data = histograma.blue;
            borderColor = 'rgba(54, 162, 235, 1)';
            break;
        case 'grayscale':
        default:
            data = histograma.grayscale;
            borderColor = 'rgba(201, 203, 207, 1)';
            break;
    }

    // Remove o gráfico anterior, se houver
    if (window.histogramChart) {
        window.histogramChart.destroy();
    }

    window.histogramChart = new Chart(canvasHistograma, {
        type: 'line',
        data: {
            labels: Array.from({ length: 256 }, (_, i) => i.toString()),
            datasets: [{
                label: 'Frequência',
                data: data,
                borderColor: borderColor,
                fill: false,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Intensidade'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Frequência'
                    }
                }
            }
        }
    });
}

// Função para calcular o histograma
function calcularHistograma(imageData) {
    const histograma = {
        red: new Array(256).fill(0),
        green: new Array(256).fill(0),
        blue: new Array(256).fill(0),
        grayscale: new Array(256).fill(0)
    };

    for (let i = 0; i < imageData.data.length; i += 4) {
        const red = imageData.data[i];
        const green = imageData.data[i + 1];
        const blue = imageData.data[i + 2];
        const grayscale = Math.round(0.299 * red + 0.587 * green + 0.114 * blue);

        histograma.red[red]++;
        histograma.green[green]++;
        histograma.blue[blue]++;
        histograma.grayscale[grayscale]++;
    }

    return histograma;
}

// Adiciona o ouvinte de evento para atualizar o histograma quando a cor selecionada mudar
document.getElementById('color-select').addEventListener('change', () => {
    const canvasOriginal = document.getElementById('canvas-original');
    const contextOriginal = canvasOriginal.getContext('2d');
    const imageData = contextOriginal.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);
    const histograma = calcularHistograma(imageData);
    desenharHistograma(histograma);
});

// Inicializa o histograma ao carregar a página
window.onload = gerarHistograma;
