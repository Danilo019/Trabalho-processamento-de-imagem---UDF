document.getElementById('color-select').addEventListener('change', gerarHistograma);

let chart = null;

function gerarHistograma() {
    const canvasOriginal = document.getElementById('canvas-original');
    const contextOriginal = canvasOriginal.getContext('2d');
    const imageData = contextOriginal.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);
    const data = imageData.data;

    const histograma = {
        red: Array(256).fill(0),
        green: Array(256).fill(0),
        blue: Array(256).fill(0),
        grayscale: Array(256).fill(0)
    };

    for (let i = 0; i < data.length; i += 4) {
        const red = data[i];
        const green = data[i + 1];
        const blue = data[i + 2];
        const grayscale = Math.round((red + green + blue) / 3);

        histograma.red[red]++;
        histograma.green[green]++;
        histograma.blue[blue]++;
        histograma.grayscale[grayscale]++;
    }

    desenharHistograma(histograma);
}

function desenharHistograma(histograma) {
    const color = document.getElementById('color-select').value;
    const canvasHistograma = document.getElementById('canvas-histograma');

    if (chart) {
        chart.destroy();
    }

    chart = new Chart(canvasHistograma, {
        type: 'bar',
        data: {
            labels: Array.from({ length: 256 }, (_, i) => i.toString()),
            datasets: [{
                label: `Frequência da cor ${color}`,
                data: histograma[color],
                backgroundColor: color,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Intensidade'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Frequência'
                    },
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: `Histograma da cor ${color}`
                }
            }
        }
    });
}
