// Adiciona ouvintes de eventos aos botões para executar ações quando clicados
document.getElementById('botao-abrir').addEventListener('click', abrirImagem);
document.getElementById('botao-processar').addEventListener('click', processarImagem);
document.getElementById('botao-escalar').addEventListener('click', escalarImagem);

// Função para lidar com a abertura de imagem
function abrirImagem() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';

    input.addEventListener('change', (event) => {
        const file = event.target.files[0];
        const url = URL.createObjectURL(file);

        const canvasOriginal = document.getElementById('canvas-original');
        const contextOriginal = canvasOriginal.getContext('2d');
        const imagemOriginal = new Image();
        imagemOriginal.src = url;

        imagemOriginal.onload = () => {
            const maxWidth = canvasOriginal.width;
            const maxHeight = canvasOriginal.height;
            const width = imagemOriginal.width;
            const height = imagemOriginal.height;

            let novaLargura = width;
            let novaAltura = height;

            if (width > height) {
                if (width > maxWidth) {
                    novaAltura *= maxWidth / width;
                    novaLargura = maxWidth;
                }
            } else {
                if (height > maxHeight) {
                    novaLargura *= maxHeight / height;
                    novaAltura = maxHeight;
                }
            }

            canvasOriginal.width = novaLargura;
            canvasOriginal.height = novaAltura;
            contextOriginal.drawImage(imagemOriginal, 0, 0, novaLargura, novaAltura);

            // Atualiza a matriz da imagem original
            const dadosImagemOriginal = contextOriginal.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);
            atualizarMatrizTexto(dadosImagemOriginal, 'matriz-text-original');
        };
    });

    input.click();
}

// Função para atualizar o texto da matriz no textarea
function atualizarMatrizTexto(dadosImagem, idTextarea) {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    const largura = dadosImagem.width;
    const altura = dadosImagem.height;

    canvas.width = largura;
    canvas.height = altura;
    context.putImageData(dadosImagem, 0, 0);

    const matrizTexto = document.getElementById(idTextarea);
    matrizTexto.value = matrizFromCanvas(canvas);
}

// Função para obter a matriz de pixels a partir do canvas
function matrizFromCanvas(canvas) {
    const context = canvas.getContext('2d');
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const dados = imageData.data;
    const largura = canvas.width;
    const altura = canvas.height;
    let matriz = '';

    for (let y = 0; y < altura; y++) {
        for (let x = 0; x < largura; x++) {
            const indice = (y * largura + x) * 4;
            matriz += `[${dados[indice]},${dados[indice + 1]},${dados[indice + 2]},${dados[indice + 3]}] `;
        }
        matriz += '\n';
    }

    return matriz;
}


// Função para lidar com o processamento de imagem
function processarImagem() {
    const menuOpcoes = document.getElementById('menu-opcoes');
    const valorOpcao = menuOpcoes.value;

    const inputAngulo = document.getElementById('input-angulo');
    const angulo = parseInt(inputAngulo.value, 10);
    const inputDeslocamentoX = document.getElementById('input-deslocamento-x');
    const deslocamentoX = parseInt(inputDeslocamentoX.value, 10);
    const inputDeslocamentoY = document.getElementById('input-deslocamento-y');
    const deslocamentoY = parseInt(inputDeslocamentoY.value, 10);

    const inputContraste = document.getElementById('input-contraste');
    const contraste = parseFloat(inputContraste.value);
    const inputSaturacao = document.getElementById('input-saturacao');
    const saturacao = parseFloat(inputSaturacao.value);

    const canvasOriginal = document.getElementById('canvas-original');
    const contextOriginal = canvasOriginal.getContext('2d');
    const dadosImagemOriginal = contextOriginal.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);

    switch (valorOpcao) {
        case 'Pixelar':
            pixelizar(dadosImagemOriginal, 10);
            break;
        case 'Negativar':
            negativar(dadosImagemOriginal);
            break;
        case 'Espelhar':
            espelhar(dadosImagemOriginal, 'horizontal');
            break;
        case 'Rotacionar':
            rotacionar(dadosImagemOriginal, angulo);
            break;
        case 'Deslocar':
            deslocar(dadosImagemOriginal, deslocamentoX, deslocamentoY);
            break;
        case 'Contraste':
            ajustarContraste(dadosImagemOriginal, contraste);
            break;
        case 'Saturacao':
            ajustarSaturacao(dadosImagemOriginal, saturacao);
            break;
        default:
            break;
    }

    const canvasProcessada = document.getElementById('canvas-processada');
    const contextProcessada = canvasProcessada.getContext('2d');

    canvasProcessada.width = canvasOriginal.width;
    canvasProcessada.height = canvasOriginal.height;

    contextProcessada.putImageData(dadosImagemOriginal, 0, 0);

    // Atualiza a matriz da imagem processada
    atualizarMatrizTexto(dadosImagemOriginal, 'matriz-text-processada');
    
}

// Função para atualizar o texto da matriz no textarea
function atualizarMatrizTexto(dadosImagem, idTextarea) {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    const largura = dadosImagem.width;
    const altura = dadosImagem.height;

    canvas.width = largura;
    canvas.height = altura;
    context.putImageData(dadosImagem, 0, 0);

    const matrizTexto = document.getElementById(idTextarea);
    matrizTexto.value = matrizFromCanvas(canvas);
}

// Função para obter a matriz de pixels a partir do canvas
function matrizFromCanvas(canvas) {
    const context = canvas.getContext('2d');
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const dados = imageData.data;
    const largura = canvas.width;
    const altura = canvas.height;
    let matriz = '';

    for (let y = 0; y < altura; y++) {
        for (let x = 0; x < largura; x++) {
            const indice = (y * largura + x) * 4;
            matriz += `[${dados[indice]},${dados[indice + 1]},${dados[indice + 2]},${dados[indice + 3]}] `;
        }
        matriz += '\n';
    }

    return matriz;
}

// Função para ajustar o contraste
function ajustarContraste(dadosImagem, intensidade) {
    const fator = (259 * (intensidade + 255)) / (255 * (259 - intensidade));
    const dados = dadosImagem.data;
    for (let i = 0; i < dados.length; i += 4) {
        dados[i] = fator * (dados[i] - 128) + 128;
        dados[i + 1] = fator * (dados[i + 1] - 128) + 128;
        dados[i + 2] = fator * (dados[i + 2] - 128) + 128;
    }
}

// Função para ajustar a saturação
function ajustarSaturacao(dadosImagem, intensidade) {
    const dados = dadosImagem.data;
    for (let i = 0; i < dados.length; i += 4) {
        const r = dados[i];
        const g = dados[i + 1];
        const b = dados[i + 2];
        const avg = (r + g + b) / 3;
        dados[i] = avg + (r - avg) * intensidade;
        dados[i + 1] = avg + (g - avg) * intensidade;
        dados[i + 2] = avg + (b - avg) * intensidade;
    }
}

// Função para pixelizar a imagem
function pixelizar(dadosImagem, tamanho) {
    const largura = dadosImagem.width;
    const altura = dadosImagem.height;

    for (let y = 0; y < altura; y += tamanho) {
        for (let x = 0; x < largura; x += tamanho) {
            let vermelho = 0,
                verde = 0,
                azul = 0,
                alfa = 0;
            const maxX = Math.min(x + tamanho, largura);
            const maxY = Math.min(y + tamanho, altura);
            const pixelsPorBloco = (maxX - x) * (maxY - y);

            for (let blocoY = y; blocoY < maxY; blocoY++) {
                for (let blocoX = x; blocoX < maxX; blocoX++) {
                    const indice = (blocoY * largura + blocoX) * 4;
                    vermelho += dadosImagem.data[indice];
                    verde += dadosImagem.data[indice + 1];
                    azul += dadosImagem.data[indice + 2];
                    alfa += dadosImagem.data[indice + 3];
                }
            }

            vermelho /= pixelsPorBloco;
            verde /= pixelsPorBloco;
            azul /= pixelsPorBloco;
            alfa /= pixelsPorBloco;

            for (let blocoY = y; blocoY < maxY; blocoY++) {
                for (let blocoX = x; blocoX < maxX; blocoX++) {
                    const indice = (blocoY * largura + blocoX) * 4;
                    dadosImagem.data[indice] = vermelho;
                    dadosImagem.data[indice + 1] = verde;
                    dadosImagem.data[indice + 2] = azul;
                    dadosImagem.data[indice + 3] = alfa;
                }
            }
        }
    }
}

// Função para negativar a imagem
function negativar(dadosImagem) {
    const dados = dadosImagem.data;
    for (let i = 0; i < dados.length; i += 4) {
        dados[i] = 255 - dados[i];
        dados[i + 1] = 255 - dados[i + 1];
        dados[i + 2] = 255 - dados[i + 2];
    }
}

// Função para espelhar a imagem
function espelhar(dadosImagem, direcao) {
    const { width, height, data } = dadosImagem;
    const espelhado = new Uint8ClampedArray(data.length);

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const indice = (y * width + x) * 4;
            let alvoX, alvoY;

            if (direcao === 'horizontal') {
                alvoX = width - x - 1;
                alvoY = y;
            } else if (direcao === 'vertical') {
                alvoX = x;
                alvoY = height - y - 1;
            }

            const indiceAlvo = (alvoY * width + alvoX) * 4;
            espelhado[indiceAlvo] = data[indice];
            espelhado[indiceAlvo + 1] = data[indice + 1];
            espelhado[indiceAlvo + 2] = data[indice + 2];
            espelhado[indiceAlvo + 3] = data[indice + 3];
        }
    }

    dadosImagem.data.set(espelhado);
}

// Função para rotacionar a imagem
function rotacionar(dadosImagem, angulo) {
    const { width, height, data } = dadosImagem;
    const rotacionado = new Uint8ClampedArray(data.length);

    const centroX = width / 2;
    const centroY = height / 2;
    const anguloRad = (angulo * Math.PI) / 180;

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const rotacionadoX = Math.round(
                (x - centroX) * Math.cos(anguloRad) - (y - centroY) * Math.sin(anguloRad) + centroX
            );
            const rotacionadoY = Math.round(
                (x - centroX) * Math.sin(anguloRad) + (y - centroY) * Math.cos(anguloRad) + centroY
            );

            if (rotacionadoX >= 0 && rotacionadoX < width && rotacionadoY >= 0 && rotacionadoY < height) {
                const indice = (y * width + x) * 4;
                const indiceRotacionado = (rotacionadoY * width + rotacionadoX) * 4;
                rotacionado[indiceRotacionado] = data[indice];
                rotacionado[indiceRotacionado + 1] = data[indice + 1];
                rotacionado[indiceRotacionado + 2] = data[indice + 2];
                rotacionado[indiceRotacionado + 3] = data[indice + 3];
            }
        }
    }

    dadosImagem.data.set(rotacionado);
}

// Função para deslocar a imagem
function deslocar(dadosImagem, deslocamentoX, deslocamentoY) {
    const { width, height, data } = dadosImagem;
    const deslocado = new Uint8ClampedArray(data.length);

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const indice = (y * width + x) * 4;
            const deslocadoX = x + deslocamentoX;
            const deslocadoY = y + deslocamentoY;

            if (deslocadoX >= 0 && deslocadoX < width && deslocadoY >= 0 && deslocadoY < height) {
                const indiceDeslocado = (deslocadoY * width + deslocadoX) * 4;
                deslocado[indiceDeslocado] = data[indice];
                deslocado[indiceDeslocado + 1] = data[indice + 1];
                deslocado[indiceDeslocado + 2] = data[indice + 2];
                deslocado[indiceDeslocado + 3] = data[indice + 3];
            }
        }
    }

    dadosImagem.data.set(deslocado);
}

// Função para escalonar a imagem
function escalarImagem() {
    const inputEscalaX = document.getElementById('input-escala-x');
    const escalaX = parseFloat(inputEscalaX.value);
    const inputEscalaY = document.getElementById('input-escala-y');
    const escalaY = parseFloat(inputEscalaY.value);

    const canvasOriginal = document.getElementById('canvas-original');
    const contextOriginal = canvasOriginal.getContext('2d');
    const dadosImagemOriginal = contextOriginal.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);

    const novaLargura = canvasOriginal.width * escalaX;
    const novaAltura = canvasOriginal.height * escalaY;

    const canvasEscalar = document.createElement('canvas');
    canvasEscalar.width = novaLargura;
    canvasEscalar.height = novaAltura;
    const contextEscalar = canvasEscalar.getContext('2d');
    contextEscalar.drawImage(canvasOriginal, 0, 0, novaLargura, novaAltura);

    const canvasProcessada = document.getElementById('canvas-processada');
    canvasProcessada.width = novaLargura;
    canvasProcessada.height = novaAltura;
    const contextProcessada = canvasProcessada.getContext('2d');
    contextProcessada.drawImage(canvasEscalar, 0, 0, novaLargura, novaAltura);
}
